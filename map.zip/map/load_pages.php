<?php
// load_pages.php

$file = 'pages.json';
if (file_exists($file)) {
    $json = file_get_contents($file);
    $pages = json_decode($json, true);
    if (!$pages) {
        $pages = ["default"];
    }
} else {
    $pages = ["default"];
}
echo json_encode($pages);
?>
