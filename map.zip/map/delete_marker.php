<?php
// Fehler in die log.txt schreiben
ini_set('log_errors', 1);
ini_set('error_log', 'log.txt');
error_reporting(E_ALL);

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? '';

if ($id === '') {
    error_log("Keine ID �bergeben");
    echo json_encode(['success' => false, 'error' => 'Keine ID �bergeben']);
    exit;
}

$csvFile = 'markers.csv';

if (!file_exists($csvFile)) {
    error_log("CSV-Datei $csvFile nicht gefunden");
    echo json_encode(['success' => false, 'error' => 'CSV-Datei nicht gefunden']);
    exit;
}

$rows = [];
// ... vorheriger Code ...

$found = false;
$lineCount = 0;

if (($handle = fopen($csvFile, "r")) !== FALSE) {
    // Optional: Header-Zeile einlesen, falls vorhanden
    $header = fgetcsv($handle);
    if ($header !== false) {
        $rows[] = $header;
    }
    while (($dataRow = fgetcsv($handle)) !== FALSE) {
        $lineCount++;
        // Angenommen, die ID ist in der ersten Spalte
        if (trim($dataRow[0]) == trim($id)) {
            $found = true;
            error_log("Marker mit ID $id in Zeile $lineCount gefunden und wird gel�scht.");
            continue;
        }
        $rows[] = $dataRow;
    }
    fclose($handle);
    error_log("Anzahl gelesener Zeilen (ohne Header): $lineCount");
} else {
    error_log("CSV-Datei $csvFile konnte nicht ge�ffnet werden");
    echo json_encode(['success' => false, 'error' => 'CSV-Datei konnte nicht ge�ffnet werden']);
    exit;
}

if (!$found) {
    error_log("Marker mit ID $id wurde nicht gefunden");
    echo json_encode(['success' => false, 'error' => 'Marker mit der angegebenen ID nicht gefunden']);
    exit;
}

// Schreibe die CSV-Datei neu und logge die Anzahl der Zeilen, die geschrieben werden
if (($handle = fopen($csvFile, "w")) !== FALSE) {
    $writeCount = 0;
    foreach ($rows as $row) {
        if (fputcsv($handle, $row) !== false) {
            $writeCount++;
        } else {
            error_log("Fehler beim Schreiben der Zeile: " . print_r($row, true));
        }
    }
    fclose($handle);
    error_log("Anzahl geschriebener Zeilen: $writeCount");
    echo json_encode(['success' => true]);
} else {
    error_log("CSV-Datei $csvFile konnte nicht zum Schreiben ge�ffnet werden");
    echo json_encode(['success' => false, 'error' => 'CSV-Datei konnte nicht geschrieben werden']);
}
