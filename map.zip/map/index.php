<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Interactive Map: Background, Markers & Panning</title>
  <style>
    /* Basis-Styling */
    body {
      margin: 0;
      overflow: hidden;
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background: #f4f7f9;
      color: #333;
    }
    /* Header (fixiert, enthält zwei Zeilen) */
    #header {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      background: #fff;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      z-index: 150;
    }
    /* Erste Zeile: Upload-Formular + Banner (iframe) */
    #form-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 20px;
    }
    #upload-form {
      margin: 0;
    }
    #upload-form input[type="file"] {
      margin-right: 10px;
    }
    #upload-form button {
      background: #007BFF;
      border: none;
      color: #fff;
      padding: 8px 16px;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.3s;
    }
    #upload-form button:hover {
      background: #0056b3;
    }
   #banner-iframe {
  width: 950px; /* Passt sich der Breite des Containers an */
  height: 121px; /* Erhöht die Höhe des iframes */
  border: none;
}
    /* Zweite Zeile: Controls (Dropdown und Toolbar) */
    #controls-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      border-top: 1px solid #ddd;
    }
    /* Page Controls (Dropdown + Buttons) */
    #page-controls {
      display: flex;
      align-items: center;
    }
    #page-controls label {
      margin-right: 8px;
    }
    #page-controls select {
      padding: 4px 8px;
      border-radius: 4px;
      border: 1px solid #ccc;
      margin-right: 5px;
    }
    #page-controls button {
      background: #28a745;
      border: none;
      color: #fff;
      padding: 6px 12px;
      border-radius: 4px;
      cursor: pointer;
      margin-right: 5px;
      transition: background 0.3s;
    }
    #page-controls button:hover {
      background: #1e7e34;
    }
    /* Toolbar */
    #toolbar {
      text-align: right;
    }
    #toolbar .icon {
      width: 40px;
      cursor: grab;
      transition: transform 0.2s;
      margin-left: 5px;
    }
    #toolbar .icon:hover {
      transform: scale(1.1);
    }
    /* Map Container – beginnt unterhalb des fixierten Headers */
    #map-container {
      position: absolute;
      top: 140px; /* Passen Sie diesen Wert ggf. an (Gesamthöhe von form-container + controls-container) */
      left: 0;
      right: 0;
      bottom: 0;
      background: #e9ecef;
      z-index: 100;
    }
    /* Canvas */
    #canvas {
      position: absolute;
      background-repeat: no-repeat;
    }
    /* Sliders */
    #hSlider, #vSlider {
      position: absolute;
      z-index: 50;
    }
    #hSlider {
      left: 0;
      right: 20px;
      bottom: 0;
    }
    #vSlider {
      top: 0;
      bottom: 20px;
      right: 0;
      transform: rotate(-90deg);
      transform-origin: center;
    }
    /* Map Marker */
    .map-marker {
      position: absolute;
      width: 40px;
      cursor: move;
      transition: transform 0.2s;
    }
    .map-marker:hover {
      transform: scale(1.1);
    }
    /* Context Menu */
    #marker-menu {
      position: absolute;
      background: #fff;
      border: 1px solid #ddd;
      padding: 10px;
      z-index: 300;
      box-shadow: 0 6px 12px rgba(0,0,0,0.15);
      display: none;
      width: 250px;
      border-radius: 6px;
    }
    #marker-menu form {
      display: flex;
      flex-direction: column;
    }
    #marker-menu label {
      font-size: 0.9em;
      margin-top: 5px;
    }
    #marker-menu input {
      margin-bottom: 8px;
      padding: 6px;
      font-size: 0.9em;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    #marker-menu button {
      background: #007BFF;
      border: none;
      color: #fff;
      padding: 8px 12px;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.3s;
    }
    #marker-menu button:hover {
      background: #0056b3;
    }
    /* Marker Info Table */
    #marker-info-table {
      margin-top: 10px;
      max-height: 150px;
      overflow-y: auto;
      border-top: 1px solid #ddd;
      padding-top: 5px;
    }
    #marker-info-table table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.9em;
    }
    #marker-info-table th, #marker-info-table td {
      border: 1px solid #ddd;
      padding: 4px 6px;
      text-align: left;
    }
    .delete-info-btn {
      color: #e74c3c;
      border: none;
      background: none;
      cursor: pointer;
      font-weight: bold;
      transition: color 0.3s;
    }
    .delete-info-btn:hover {
      color: #c0392b;
    }
  </style>
</head>
<body>
  <!-- Header -->
  <div id="header">
    <!-- Erste Zeile: Upload Form + Banner Iframe -->
    <div id="form-container">
      <form id="upload-form" enctype="multipart/form-data">
        <input type="file" id="bgUploader" name="bgImage" accept="image/*">
        <button type="submit">Upload</button>
      </form>
      <iframe id="banner-iframe" src="https://itfourall.com/mapstruct-banner.php"></iframe>
    </div>
    <!-- Zweite Zeile: Page Dropdown & Toolbar -->
    <div id="controls-container">
      <div id="page-controls">
        <label for="page-selector">Page:</label>
        <select id="page-selector"></select>
        <button id="copy-page-link">Copy Link</button>
        <button id="add-page">New Page</button>
        <button id="delete-page">Delete Page</button>
      </div>
      <div id="toolbar">
        <img id="marker1" class="icon" src="img/marker_1.png" alt="Marker 1" draggable="true" data-type="marker_1">
        <img id="marker2" class="icon" src="img/marker_2.png" alt="Marker 2" draggable="true" data-type="marker_2">
        <img id="marker3" class="icon" src="img/marker_3.png" alt="Marker 3" draggable="true" data-type="marker_3">
        <img id="marker4" class="icon" src="img/marker_4.png" alt="Marker 4" draggable="true" data-type="marker_4">
        <img id="marker5" class="icon" src="img/marker_5.png" alt="Marker 5" draggable="true" data-type="marker_5">
        <img id="marker6" class="icon" src="img/marker_6.png" alt="Marker 6" draggable="true" data-type="marker_6">
        <img id="marker7" class="icon" src="img/marker_7.png" alt="Marker 7" draggable="true" data-type="marker_7">
        <img id="marker8" class="icon" src="img/marker_8.png" alt="Marker 8" draggable="true" data-type="marker_8">
        <img id="marker9" class="icon" src="img/marker_9.png" alt="Marker 9" draggable="true" data-type="marker_9">
        <img id="marker10" class="icon" src="img/marker_10.png" alt="Marker 10" draggable="true" data-type="marker_10">
        <img id="marker11" class="icon" src="img/marker_11.png" alt="Marker 11" draggable="true" data-type="marker_11">
        <img id="marker12" class="icon" src="img/marker_12.png" alt="Marker 12" draggable="true" data-type="marker_12">
        <img id="marker13" class="icon" src="img/marker_13.png" alt="Marker 13" draggable="true" data-type="marker_13">
        <img id="marker14" class="icon" src="img/marker_14.png" alt="Marker 14" draggable="true" data-type="marker_14">
        <img id="marker15" class="icon" src="img/marker_15.png" alt="Marker 15" draggable="true" data-type="marker_15">
        <img id="marker16" class="icon" src="img/marker_16.png" alt="Marker 16" draggable="true" data-type="marker_16">
        <img id="marker17" class="icon" src="img/marker_17.png" alt="Marker 17" draggable="true" data-type="marker_17">
        <img id="marker18" class="icon" src="img/marker_18.png" alt="Marker 18" draggable="true" data-type="marker_18">
        <img id="marker19" class="icon" src="img/marker_19.png" alt="Marker 19" draggable="true" data-type="marker_19">
        <img id="marker20" class="icon" src="img/marker_20.png" alt="Marker 20" draggable="true" data-type="marker_20">
      </div>
    </div>
  </div>
  
  <!-- Map Container (beginnt unterhalb des Headers) -->
  <div id="map-container">
    <div id="canvas"></div>
    <input type="range" id="hSlider" min="0" max="0" value="0">
    <input type="range" id="vSlider" min="0" max="0" value="0">
  </div>
  
  <!-- Context Menu -->
  <div id="marker-menu">
    <form id="marker-info-form">
      <label for="marker-designation">Designation:</label>
      <input type="text" id="marker-designation" name="designation" placeholder="New designation">
      <label for="marker-link">Link:</label>
      <input type="text" id="marker-link" name="link" placeholder="http://...">
      <button type="button" id="save-marker-info-btn">Save</button>
    </form>
    <div id="marker-info-table"><!-- CSV table will be shown here --></div>
    <button id="delete-marker-btn">Delete</button>
  </div>
  
  <script>
    // URL-Parameter "page" auslesen
    function getQueryParameter(param) {
      const params = new URLSearchParams(window.location.search);
      return params.get(param);
    }
    let currentPage = "default";
    const urlPage = getQueryParameter('page');
    if (urlPage) currentPage = urlPage;
    window.history.replaceState({}, "", window.location.pathname + "?page=" + encodeURIComponent(currentPage));
    
    const canvas = document.getElementById('canvas');
    const mapContainer = document.getElementById('map-container');
    const hSlider = document.getElementById('hSlider');
    const vSlider = document.getElementById('vSlider');
    
    const uploadForm = document.getElementById('upload-form');
    const bgUploader = document.getElementById('bgUploader');
    
    // Alle Icons aus der Toolbar holen
    const toolbarMarkers = document.querySelectorAll('#toolbar .icon');
    
    const pageSelector = document.getElementById('page-selector');
    const addPageBtn = document.getElementById('add-page');
    const deletePageBtn = document.getElementById('delete-page');
    const copyPageLinkBtn = document.getElementById('copy-page-link');
    
    const markerMenu = document.getElementById('marker-menu');
    const deleteMarkerBtn = document.getElementById('delete-marker-btn');
    const saveMarkerInfoBtn = document.getElementById('save-marker-info-btn');
    const markerDesignation = document.getElementById('marker-designation');
    const markerLink = document.getElementById('marker-link');
    const markerInfoTable = document.getElementById('marker-info-table');
    
    let availablePages = [];
    let currentMarkerEl = null;
    
    function loadBackground() {
      fetch('config.json?' + Date.now())
      .then(response => {
        if (!response.ok) throw new Error("config.json not found");
        return response.json();
      })
      .then(data => {
        if (data[currentPage]) {
          let img = new Image();
          img.onload = function() {
            canvas.style.width = img.naturalWidth + "px";
            canvas.style.height = img.naturalHeight + "px";
            canvas.style.backgroundImage = `url(${data[currentPage]})`;
            canvas.style.backgroundSize = "auto";
            canvas.style.backgroundPosition = "top left";
            const containerWidth = mapContainer.clientWidth;
            const containerHeight = mapContainer.clientHeight;
            const offsetLeft = (containerWidth - img.naturalWidth) / 2;
            const offsetTop = (containerHeight - img.naturalHeight) / 2;
            canvas.style.left = offsetLeft + "px";
            canvas.style.top = offsetTop + "px";
            updateSliders();
          }
          img.src = data[currentPage];
        } else {
          canvas.style.backgroundImage = "";
          canvas.style.backgroundColor = "white";
        }
      })
      .catch(error => {
        console.error("Error loading background:", error);
        canvas.style.backgroundImage = "";
        canvas.style.backgroundColor = "white";
      });
    }
    loadBackground();
    
    function updateSliders() {
      const containerWidth = mapContainer.clientWidth;
      const containerHeight = mapContainer.clientHeight;
      const canvasWidth = canvas.clientWidth;
      const canvasHeight = canvas.clientHeight;
      const maxH = Math.max(0, canvasWidth - containerWidth);
      const maxV = Math.max(0, canvasHeight - containerHeight);
      hSlider.max = maxH;
      vSlider.max = maxV;
      const currentLeft = parseInt(canvas.style.left) || 0;
      const currentTop = parseInt(canvas.style.top) || 0;
      hSlider.value = -currentLeft;
      vSlider.value = -currentTop;
    }
    
    uploadForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const file = bgUploader.files[0];
      if (!file) return;
      const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
      if (!allowedTypes.includes(file.type)) {
        alert("Wrong format. Please upload a JPEG, PNG, GIF or WEBP image.");
        return;
      }
      const formData = new FormData();
      formData.append('bgImage', file);
      formData.append('page', currentPage);
      fetch('upload.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) loadBackground();
        else alert("Upload error: " + data.error);
      })
      .catch(error => console.error("Upload error:", error));
    });
    
    // Dragstart-Event für alle Toolbar-Icons
    toolbarMarkers.forEach(marker => {
      marker.addEventListener('dragstart', function(e) {
        e.dataTransfer.setData('text/plain', marker.id);
      });
    });
    
    mapContainer.addEventListener('dragover', function(e) {
      e.preventDefault();
    });
    
    // Drop-Handler: Marker erstellen
    mapContainer.addEventListener('drop', function(e) {
      e.preventDefault();
      const draggedId = e.dataTransfer.getData('text/plain');
      const draggedEl = document.getElementById(draggedId);
      if (draggedEl) {
        const newMarker = document.createElement('img');
        newMarker.src = draggedEl.src;
        newMarker.dataset.type = draggedEl.dataset.type;
        newMarker.className = 'map-marker';
        newMarker.id = "marker-" + Date.now();
        const canvasRect = canvas.getBoundingClientRect();
        let dropX = e.clientX - canvasRect.left;
        let dropY = e.clientY - canvasRect.top;
        newMarker.style.left = (dropX - 20) + "px";
        newMarker.style.top = (dropY - 20) + "px";
        canvas.appendChild(newMarker);
        makeDraggable(newMarker);
        saveMarkerData(newMarker);
      }
    });
    
    function makeDraggable(el) {
      el.addEventListener('mousedown', function(e) {
        e.preventDefault();
        const startX = e.pageX;
        const startY = e.pageY;
        const origLeft = parseInt(el.style.left, 10) || 0;
        const origTop = parseInt(el.style.top, 10) || 0;
        function onMouseMove(e) {
          const dx = e.pageX - startX;
          const dy = e.pageY - startY;
          el.style.left = (origLeft + dx) + "px";
          el.style.top = (origTop + dy) + "px";
        }
        function onMouseUp() {
          document.removeEventListener('mousemove', onMouseMove);
          document.removeEventListener('mouseup', onMouseUp);
          saveMarkerData(el);
        }
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });
      el.ondragstart = () => false;
      
      el.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        currentMarkerEl = el;
        markerMenu.style.display = "block";
        let posX = e.pageX;
        let posY = e.pageY;
        const menuWidth = markerMenu.offsetWidth;
        const viewportWidth = window.innerWidth;
        if (posX + menuWidth > viewportWidth) {
          posX = viewportWidth - menuWidth - 5;
        }
        const menuHeight = markerMenu.offsetHeight;
        const viewportHeight = window.innerHeight;
        if (posY + menuHeight > viewportHeight) {
          posY = viewportHeight - menuHeight - 5;
        }
        markerMenu.style.left = posX + "px";
        markerMenu.style.top = posY + "px";
        markerDesignation.value = "";
        markerLink.value = "";
        loadMarkerInfoList(el.id);
      });
    }
    
    function loadMarkerInfoList(markerId) {
      fetch('load_marker_info.php?markerId=' + encodeURIComponent(markerId))
      .then(response => response.json())
      .then(data => {
        let html = "";
        if (data.success && data.infoList && data.infoList.length > 0) {
          html += "<table>";
          html += "<tr><th>Designation</th><th>Delete</th></tr>";
          data.infoList.forEach(entry => {
            let designationHtml = (entry.link && entry.link.trim() !== "")
              ? "<a href='" + entry.link + "' target='_blank' title='" + entry.link + "'>" + entry.designation + "</a>"
              : entry.designation;
            html += "<tr><td>" + designationHtml + "</td><td><button class='delete-info-btn' onclick='deleteMarkerInfo(\"" + markerId + "\", \"" + encodeURIComponent(entry.designation) + "\")'>X</button></td></tr>";
          });
          html += "</table>";
        } else {
          html = "<p>No entries available.</p>";
        }
        markerInfoTable.innerHTML = html;
      })
      .catch(err => {
        console.error("Error loading marker info:", err);
        markerInfoTable.innerHTML = "<p>Error loading marker info.</p>";
      });
    }
    
    function deleteMarkerInfo(markerId, encodedDesignation) {
      const designation = decodeURIComponent(encodedDesignation);
      fetch('delete_marker_info.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: markerId, designation: designation })
      })
      .then(response => response.json())
      .then(result => {
        if (result.success) loadMarkerInfoList(markerId);
        else alert("Error deleting entry: " + result.error);
      })
      .catch(err => console.error("Error deleting marker info:", err));
    }
    
    saveMarkerInfoBtn.addEventListener('click', function() {
      if (!currentMarkerEl) return;
      if (markerDesignation.value.trim() === "") {
        alert("Designation cannot be empty.");
        return;
      }
      const infoData = {
        id: currentMarkerEl.id,
        designation: markerDesignation.value,
        link: markerLink.value
      };
      fetch('save_marker_info.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(infoData)
      })
      .then(response => response.json())
      .then(() => {
        hideMarkerMenu();
        window.location.href = window.location.pathname + "?page=" + encodeURIComponent(currentPage) + "&t=" + Date.now();
      })
      .catch(err => {
        console.error("Error saving marker info:", err);
        hideMarkerMenu();
        window.location.href = window.location.pathname + "?page=" + encodeURIComponent(currentPage) + "&t=" + Date.now();
      });
    });
    
    deleteMarkerBtn.addEventListener('click', function() {
      if (!currentMarkerEl) return;
      fetch('delete_marker.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: currentMarkerEl.id })
      })
      .then(response => response.json())
      .then(result => {
        if (result.success) {
          hideMarkerMenu();
          window.location.href = window.location.pathname + "?page=" + encodeURIComponent(currentPage);
        } else {
          alert("Error deleting marker.");
        }
      })
      .catch(err => console.error("Error deleting marker:", err));
    });
    
    function saveMarkerData(markerEl) {
      const data = {
        id: markerEl.id,
        left: markerEl.style.left,
        top: markerEl.style.top,
        src: markerEl.src,
        type: markerEl.dataset.type || "",
        page: currentPage
      };
      fetch('save_marker.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      .then(response => response.json())
      .then(result => {
        if (!result.success) console.error("Error saving marker:", result.error);
      })
      .catch(err => console.error("Error sending marker data:", err));
    }
    
    function loadMarkersForPage(page) {
      fetch('load_markers.php')
      .then(response => response.json())
      .then(markers => {
        markers.filter(marker => marker.page === page)
        .forEach(data => {
          const markerEl = document.createElement('img');
          markerEl.id = data.id;
          markerEl.src = data.src;
          markerEl.className = 'map-marker';
          markerEl.style.left = data.left;
          markerEl.style.top = data.top;
          markerEl.dataset.type = data.type || "";
          canvas.appendChild(markerEl);
          makeDraggable(markerEl);
        });
      })
      .catch(err => console.error("Error loading markers:", err));
    }
    
    hSlider.addEventListener('input', function() {
      canvas.style.left = -hSlider.value + "px";
    });
    vSlider.addEventListener('input', function() {
      canvas.style.top = -vSlider.value + "px";
    });
    
    mapContainer.addEventListener("wheel", function(e) {
      e.preventDefault();
      if (e.shiftKey) {
        let newVal = parseInt(hSlider.value) + e.deltaY;
        newVal = Math.min(hSlider.max, Math.max(0, newVal));
        hSlider.value = newVal;
        canvas.style.left = -hSlider.value + "px";
      } else {
        let newVal = parseInt(vSlider.value) + e.deltaY;
        newVal = Math.min(vSlider.max, Math.max(0, newVal));
        vSlider.value = newVal;
        canvas.style.top = -vSlider.value + "px";
      }
    }, {passive:false});
    
    function updatePageSelector() {
      pageSelector.innerHTML = "";
      availablePages.forEach(page => {
        const option = document.createElement("option");
        option.value = page;
        option.textContent = page;
        if (page === currentPage) option.selected = true;
        pageSelector.appendChild(option);
      });
      pageSelector.title = window.location.origin + window.location.pathname + "?page=" + encodeURIComponent(currentPage);
    }
    
    function loadPages() {
      fetch('load_pages.php')
      .then(response => response.json())
      .then(pages => {
        availablePages = (pages && pages.length) ? pages : ["default"];
        if (!availablePages.includes("default")) availablePages.unshift("default");
        if (!availablePages.includes(currentPage)) currentPage = availablePages[0];
        updatePageSelector();
        clearMarkers();
        loadMarkersForPage(currentPage);
        loadBackground();
      })
      .catch(err => {
        console.error("Error loading pages:", err);
        availablePages = ["default"];
        currentPage = "default";
        updatePageSelector();
        clearMarkers();
        loadMarkersForPage(currentPage);
        loadBackground();
      });
    }
    
    addPageBtn.addEventListener("click", () => {
      let newPage = prompt("Enter new page name:");
      if (newPage && !availablePages.includes(newPage)) {
        fetch('save_page.php', {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ page: newPage })
        })
        .then(response => response.json())
        .then(result => {
          if (result.success) {
            availablePages.push(newPage);
            currentPage = newPage;
            updatePageSelector();
            clearMarkers();
            loadMarkersForPage(currentPage);
            loadBackground();
            window.history.replaceState({}, "", window.location.pathname + "?page=" + encodeURIComponent(currentPage));
          } else {
            alert("Error adding page.");
          }
        });
      }
    });
    
    deletePageBtn.addEventListener("click", () => {
      if (currentPage === "default") {
        alert("The default page cannot be deleted.");
        return;
      }
      if (confirm(`Delete page "${currentPage}"?`)) {
        fetch('delete_page.php', {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ page: currentPage })
        })
        .then(response => response.json())
        .then(result => {
          if (result.success) {
            availablePages = availablePages.filter(page => page !== currentPage);
            currentPage = availablePages[0] || "default";
            updatePageSelector();
            clearMarkers();
            loadMarkersForPage(currentPage);
            loadBackground();
            window.history.replaceState({}, "", window.location.pathname + "?page=" + encodeURIComponent(currentPage));
          } else {
            alert("Error deleting page.");
          }
        });
      }
    });
    
    pageSelector.addEventListener("change", (e) => {
      currentPage = e.target.value;
      window.history.replaceState({}, "", window.location.pathname + "?page=" + encodeURIComponent(currentPage));
      updatePageSelector();
      clearMarkers();
      loadMarkersForPage(currentPage);
      loadBackground();
    });
    
    copyPageLinkBtn.addEventListener('click', () => {
      const link = window.location.origin + window.location.pathname + "?page=" + encodeURIComponent(currentPage);
      navigator.clipboard.writeText(link)
      .then(() => {
        copyPageLinkBtn.textContent = "Copied!";
        setTimeout(() => {
          copyPageLinkBtn.textContent = "Copy Link";
        }, 2000);
      })
      .catch(err => {
        console.error("Error copying link: ", err);
      });
    });
    
    function clearMarkers() {
      document.querySelectorAll('.map-marker').forEach(m => m.remove());
    }
    
    // Hide context menu when clicking outside
    document.addEventListener('click', function(e) {
      if (!markerMenu.contains(e.target)) hideMarkerMenu();
    });
    
    function hideMarkerMenu() {
      markerMenu.style.display = "none";
      currentMarkerEl = null;
    }
    
    loadPages();
  </script>
</body>
</html>
