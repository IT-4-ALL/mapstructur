<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

$data = json_decode(file_get_contents('php://input'), true);
$markerId = $data['id'] ?? '';
$designation = $data['designation'] ?? '';

if ($markerId === '' || trim($designation) === '') {
    echo json_encode(['success' => false, 'error' => 'Marker-ID und Bezeichnung m�ssen �bergeben werden']);
    exit;
}

$csvFile = 'marker_info.csv';
if (!file_exists($csvFile)) {
    echo json_encode(['success' => false, 'error' => 'CSV-Datei nicht gefunden']);
    exit;
}

$rows = [];
$found = false;

if (($handle = fopen($csvFile, "r")) !== FALSE) {
    while (($row = fgetcsv($handle)) !== FALSE) {
        // Pr�fen, ob Marker-ID und Bezeichnung �bereinstimmen
        if (isset($row[0], $row[1]) &&
            trim($row[0]) === trim($markerId) &&
            trim($row[1]) === trim($designation)) {
            $found = true;
            continue;
        }
        $rows[] = $row;
    }
    fclose($handle);
} else {
    echo json_encode(['success' => false, 'error' => 'CSV-Datei konnte nicht ge�ffnet werden']);
    exit;
}

if (!$found) {
    echo json_encode(['success' => false, 'error' => 'Eintrag nicht gefunden']);
    exit;
}

if (($handle = fopen($csvFile, "w")) !== FALSE) {
    foreach ($rows as $row) {
        fputcsv($handle, $row);
    }
    fclose($handle);
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'CSV konnte nicht geschrieben werden']);
}
?>
