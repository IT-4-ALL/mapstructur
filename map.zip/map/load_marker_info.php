<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', 'log.txt');

$markerId = $_GET['markerId'] ?? '';
if ($markerId === '') {
    echo json_encode(['success' => false, 'error' => 'Keine Marker-ID übergeben']);
    exit;
}

$csvFile = 'marker_info.csv';
if (!file_exists($csvFile)) {
    echo json_encode(['success' => false, 'error' => 'CSV-Datei nicht gefunden']);
    exit;
}

$infoList = [];
if (($handle = fopen($csvFile, "r")) !== FALSE) {
    while (($data = fgetcsv($handle)) !== FALSE) {
        // Prüfe, ob Spalte 0 existiert, bevor trim() aufgerufen wird
        if (isset($data[0]) && trim($data[0]) === trim($markerId)) {
            $infoList[] = [
                'designation' => isset($data[1]) ? $data[1] : '',
                'link' => isset($data[2]) ? $data[2] : ''
            ];
        }
    }
    fclose($handle);
}

echo json_encode(['success' => true, 'infoList' => $infoList]);
?>
