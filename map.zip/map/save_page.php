<?php
// save_page.php

$file = 'pages.json';

// Vorhandene Seiten laden, falls vorhanden
if (file_exists($file)) {
    $json = file_get_contents($file);
    $pages = json_decode($json, true);
    if (!is_array($pages)) {
        $pages = [];
    }
} else {
    $pages = ["default"];
}

// Eingehende Daten lesen (z.B. { "page": "NeueSeite" })
$data = json_decode(file_get_contents('php://input'), true);
if (!$data || !isset($data['page'])) {
    echo json_encode(["success" => false, "error" => "Keine g�ltigen Daten empfangen."]);
    exit;
}

$newPage = trim($data['page']);
if ($newPage === "" || in_array($newPage, $pages)) {
    echo json_encode(["success" => false, "error" => "Seite existiert bereits oder ung�ltiger Name."]);
    exit;
}

$pages[] = $newPage;

// Seiten in der JSON-Datei speichern
if (file_put_contents($file, json_encode($pages))) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => "Konnte die Datei nicht speichern."]);
}
?>
