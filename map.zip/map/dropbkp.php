<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>Interaktive Karte: Hintergrund, Marker & Panning</title>
  <style>
    body {
      margin: 0;
      overflow: hidden;
      font-family: sans-serif;
    }
    /* Obere Bereiche bleiben immer sichtbar */
    #upload-form {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      z-index: 150;
      background: rgba(255,255,255,0.9);
      padding: 10px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    /* Seitenverwaltung � �ber dem Toolbar-Bereich */
    #page-controls {
      position: absolute;
      top: 60px;
      left: 10px;
      z-index: 200; /* H�her als Toolbar */
      background: rgba(255,255,255,0.9);
      padding: 10px;
      border-radius: 4px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    /* Toolbar: Marker � bleibt sichtbar, aber unterhalb der Seitenverwaltung */
    #toolbar {
      position: absolute;
      top: 60px;
      right: 10px;
      z-index: 150;
      background: rgba(255,255,255,0.9);
      padding: 10px;
      border-radius: 4px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      text-align: right;
    }
    
    /* Map-Container: belegt den restlichen Bereich unterhalb der oberen Bereiche */
    #map-container {
      position: absolute;
      top: 120px; /* oberer Bereich (Upload, Page-Controls, Toolbar) */
      left: 0;
      right: 0;
      bottom: 0;
      overflow: hidden;
      background: #eee;
      z-index: 100;
    }
    
    /* Canvas: enth�lt das Hintergrundbild (Originalgr��e) und Marker */
    #canvas {
      position: absolute;
      background-repeat: no-repeat;
      /* Gr��e und Position werden dynamisch gesetzt */
    }
    
    /* Slider-Steuerelemente f�r horizontales und vertikales Panning */
    #hSlider {
      position: absolute;
      left: 0;
      right: 20px; /* Platz f�r den vertikalen Slider */
      bottom: 0;
      z-index: 50;
    }
    #vSlider {
      position: absolute;
      top: 0;
      bottom: 20px; /* Platz f�r den horizontalen Slider */
      right: 0;
      z-index: 50;
      transform: rotate(-90deg);
      transform-origin: center;
    }
    
    /* Marker in der Toolbar */
    .icon {
      width: 40px;
      cursor: grab;
    }
    /* Marker, die auf der Map platziert werden */
    .map-marker {
      position: absolute;
      width: 40px;
      cursor: move;
    }
  </style>
</head>
<body>
  <!-- Upload-Formular f�r das Hintergrundbild -->
  <form id="upload-form" enctype="multipart/form-data">
    <input type="file" id="bgUploader" name="bgImage" accept="image/*">
    <button type="submit">Hochladen</button>
  </form>
  
  <!-- Seitenverwaltung: Dropdown, Neue Seite & Seite l�schen -->
  <div id="page-controls">
    <label for="page-selector">Seite:</label>
    <select id="page-selector"></select>
    <button id="add-page">Neue Seite</button>
    <button id="delete-page">Seite l�schen</button>
  </div>
  
  <!-- Toolbar: Marker (marker.png) � bleibt immer sichtbar -->
  <div id="toolbar">
    <img id="marker" class="icon" src="img/marker.png" alt="Marker" draggable="true" data-type="marker_1">
  </div>
  
  <!-- Map-Container -->
  <div id="map-container">
    <!-- Canvas: hier wird das Hintergrundbild in Originalgr��e angezeigt -->
    <div id="canvas"></div>
    <!-- Slider f�r horizontales Panning -->
    <input type="range" id="hSlider" min="0" max="0" value="0">
    <!-- Slider f�r vertikales Panning -->
    <input type="range" id="vSlider" min="0" max="0" value="0">
  </div>
  
  <script>
    const canvas = document.getElementById('canvas');
    const mapContainer = document.getElementById('map-container');
    const hSlider = document.getElementById('hSlider');
    const vSlider = document.getElementById('vSlider');
    
    const uploadForm = document.getElementById('upload-form');
    const bgUploader = document.getElementById('bgUploader');
    const marker = document.getElementById('marker');
    const pageSelector = document.getElementById('page-selector');
    const addPageBtn = document.getElementById('add-page');
    const deletePageBtn = document.getElementById('delete-page');
    
    let currentPage = "default";
    let availablePages = [];
    
    // Hintergrund laden: F�r currentPage wird das Bild in Originalgr��e geladen
    function loadBackground() {
      fetch('config.json?' + Date.now())
        .then(response => {
          if (!response.ok) throw new Error("Keine config.json gefunden");
          return response.json();
        })
        .then(data => {
          if (data[currentPage]) {
            let img = new Image();
            img.onload = function() {
              // Setze die Canvas-Gr��e auf die Originalgr��e des Bildes
              canvas.style.width = img.naturalWidth + "px";
              canvas.style.height = img.naturalHeight + "px";
              canvas.style.backgroundImage = `url(${data[currentPage]})`;
              canvas.style.backgroundSize = "auto";
              canvas.style.backgroundPosition = "top left";
              // Zentriere das Bild im mapContainer
              const containerWidth = mapContainer.clientWidth;
              const containerHeight = mapContainer.clientHeight;
              const offsetLeft = (containerWidth - img.naturalWidth) / 2;
              const offsetTop = (containerHeight - img.naturalHeight) / 2;
              canvas.style.left = offsetLeft + "px";
              canvas.style.top = offsetTop + "px";
              updateSliders();
            }
            img.src = data[currentPage];
          } else {
            canvas.style.backgroundImage = "";
            canvas.style.backgroundColor = "white";
          }
        })
        .catch(error => {
          console.error("Fehler beim Laden des Hintergrunds:", error);
          canvas.style.backgroundImage = "";
          canvas.style.backgroundColor = "white";
        });
    }
    loadBackground();
    
    // Slider aktualisieren: Bestimme die Maximalwerte basierend auf der Gr��e von canvas und mapContainer.
    function updateSliders() {
      const containerWidth = mapContainer.clientWidth;
      const containerHeight = mapContainer.clientHeight;
      const canvasWidth = canvas.clientWidth;
      const canvasHeight = canvas.clientHeight;
      
      const maxH = Math.max(0, canvasWidth - containerWidth);
      const maxV = Math.max(0, canvasHeight - containerHeight);
      
      hSlider.max = maxH;
      vSlider.max = maxV;
      
      // Positioniere die Slider so, dass der Canvas zentriert bleibt
      const currentLeft = parseInt(canvas.style.left) || 0;
      const currentTop = parseInt(canvas.style.top) || 0;
      hSlider.value = -currentLeft;
      vSlider.value = -currentTop;
    }
    
    // Upload des Hintergrundbildes: currentPage wird mit�bertragen.
    uploadForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const file = bgUploader.files[0];
      if (!file) return;
      const formData = new FormData();
      formData.append('bgImage', file);
      formData.append('page', currentPage);
      
      fetch('upload.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          loadBackground();
        } else {
          alert("Upload-Fehler: " + data.error);
        }
      })
      .catch(error => console.error("Upload-Fehler:", error));
    });
    
    // Marker aus der Toolbar als Drag-Quelle
    marker.addEventListener('dragstart', function(e) {
      e.dataTransfer.setData('text/plain', 'marker');
    });
    
    // Erlaubt das Ablegen (drop) im mapContainer (Canvas liegt darin)
    mapContainer.addEventListener('dragover', function(e) {
      e.preventDefault();
    });
    
    // Marker auf der Map platzieren
    mapContainer.addEventListener('drop', function(e) {
      e.preventDefault();
      const data = e.dataTransfer.getData('text/plain');
      if (data === 'marker') {
        const newMarker = document.createElement('img');
        newMarker.src = marker.src;
        newMarker.className = 'map-marker';
        newMarker.id = "marker-" + Date.now();
        newMarker.dataset.type = marker.dataset.type; // data-type �bernehmen
        const containerRect = mapContainer.getBoundingClientRect();
        let offsetX = e.clientX - containerRect.left;
        let offsetY = e.clientY - containerRect.top;
        newMarker.style.left = (offsetX + parseInt(hSlider.value) - 20) + "px";
        newMarker.style.top = (offsetY + parseInt(vSlider.value) - 20) + "px";
        canvas.appendChild(newMarker);
        makeDraggable(newMarker);
        saveMarkerData(newMarker);
      }
    });
    
    // Marker verschiebbar machen
    function makeDraggable(el) {
      el.addEventListener('mousedown', function(e) {
        e.preventDefault();
        let offsetX = e.clientX - el.getBoundingClientRect().left;
        let offsetY = e.clientY - el.getBoundingClientRect().top;
        
        function onMouseMove(e) {
          el.style.left = (e.clientX - mapContainer.getBoundingClientRect().left - offsetX + parseInt(hSlider.value)) + "px";
          el.style.top = (e.clientY - mapContainer.getBoundingClientRect().top - offsetY + parseInt(vSlider.value)) + "px";
        }
        function onMouseUp() {
          document.removeEventListener('mousemove', onMouseMove);
          document.removeEventListener('mouseup', onMouseUp);
          saveMarkerData(el);
        }
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });
      el.ondragstart = () => false;
    }
    
    // Marker-Daten (inkl. currentPage) speichern (in markers.csv)
    function saveMarkerData(markerEl) {
      const data = {
        id: markerEl.id,
        left: markerEl.style.left,
        top: markerEl.style.top,
        src: markerEl.src,
        type: markerEl.dataset.type || "",
        page: currentPage
      };
      fetch('save_marker.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      .then(response => response.json())
      .then(result => {
        if (!result.success) console.error("Fehler beim Speichern des Markers:", result.error);
      })
      .catch(err => console.error("Fehler beim Senden der Marker-Daten:", err));
    }
    
    // Marker der aktuellen Seite laden
    function loadMarkersForPage(page) {
      fetch('load_markers.php')
        .then(response => response.json())
        .then(markers => {
          markers.filter(marker => marker.page === page)
            .forEach(data => {
              const markerEl = document.createElement('img');
              markerEl.id = data.id;
              markerEl.src = data.src;
              markerEl.className = 'map-marker';
              markerEl.style.left = data.left;
              markerEl.style.top = data.top;
              markerEl.dataset.type = data.type || "";
              canvas.appendChild(markerEl);
              makeDraggable(markerEl);
            });
        })
        .catch(err => console.error("Fehler beim Laden der Marker:", err));
    }
    
    // Slider: Panning per Slider-Input
    hSlider.addEventListener('input', function() {
      canvas.style.left = -hSlider.value + "px";
    });
    vSlider.addEventListener('input', function() {
      canvas.style.top = -vSlider.value + "px";
    });
    
    // Mausrad-Steuerung f�r den Slider
    mapContainer.addEventListener("wheel", function(e) {
      e.preventDefault();
      // Mit Shift-Taste horizontal scrollen, sonst vertikal
      if (e.shiftKey) {
        let newVal = parseInt(hSlider.value) + e.deltaY;
        newVal = Math.min(hSlider.max, Math.max(0, newVal));
        hSlider.value = newVal;
        canvas.style.left = -hSlider.value + "px";
      } else {
        let newVal = parseInt(vSlider.value) + e.deltaY;
        newVal = Math.min(vSlider.max, Math.max(0, newVal));
        vSlider.value = newVal;
        canvas.style.top = -vSlider.value + "px";
      }
    });
    
    // Seitenverwaltung: Laden, Hinzuf�gen, L�schen
    function updatePageSelector() {
      pageSelector.innerHTML = "";
      availablePages.forEach(page => {
        const option = document.createElement("option");
        option.value = page;
        option.textContent = page;
        if (page === currentPage) option.selected = true;
        pageSelector.appendChild(option);
      });
    }
    
    function loadPages() {
      fetch('load_pages.php')
        .then(response => response.json())
        .then(pages => {
          availablePages = (pages && pages.length) ? pages : ["default"];
          if (!availablePages.includes("default")) availablePages.unshift("default");
          currentPage = availablePages[0];
          updatePageSelector();
          clearMarkers();
          loadMarkersForPage(currentPage);
          loadBackground();
        })
        .catch(err => {
          console.error("Fehler beim Laden der Seiten:", err);
          availablePages = ["default"];
          currentPage = "default";
          updatePageSelector();
          clearMarkers();
          loadMarkersForPage(currentPage);
          loadBackground();
        });
    }
    
    addPageBtn.addEventListener("click", () => {
      let newPage = prompt("Neuen Seitennamen eingeben:");
      if (newPage && !availablePages.includes(newPage)) {
        fetch('save_page.php', {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ page: newPage })
        })
        .then(response => response.json())
        .then(result => {
          if (result.success) {
            availablePages.push(newPage);
            currentPage = newPage;
            updatePageSelector();
            clearMarkers();
            loadMarkersForPage(currentPage);
            loadBackground();
          } else {
            alert("Fehler beim Hinzuf�gen der Seite.");
          }
        });
      }
    });
    
    deletePageBtn.addEventListener("click", () => {
      if (currentPage === "default") {
        alert("Die Standardseite 'default' kann nicht gel�scht werden.");
        return;
      }
      if (confirm(`Seite "${currentPage}" wirklich l�schen?`)) {
        fetch('delete_page.php', {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ page: currentPage })
        })
        .then(response => response.json())
        .then(result => {
          if (result.success) {
            availablePages = availablePages.filter(page => page !== currentPage);
            currentPage = availablePages[0] || "default";
            updatePageSelector();
            clearMarkers();
            loadMarkersForPage(currentPage);
            loadBackground();
          } else {
            alert("Fehler beim L�schen der Seite.");
          }
        });
      }
    });
    
    pageSelector.addEventListener("change", (e) => {
      currentPage = e.target.value;
      clearMarkers();
      loadMarkersForPage(currentPage);
      loadBackground();
    });
    
    // Helper: Entfernt alle Marker vom Canvas
    function clearMarkers() {
      document.querySelectorAll('.map-marker').forEach(m => m.remove());
    }
    
    // Seiten beim Start laden
    loadPages();
  </script>
</body>
</html>

