<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

$data = json_decode(file_get_contents('php://input'), true);
$markerId = $data['id'] ?? '';
$designation = $data['designation'] ?? '';
$link = $data['link'] ?? '';

if ($markerId === '') {
    echo json_encode(['success' => false, 'error' => 'Keine Marker-ID übergeben']);
    exit;
}

$csvFile = 'marker_info.csv';
$rows = [];

// CSV einlesen, falls vorhanden
if (file_exists($csvFile)) {
    if (($handle = fopen($csvFile, "r")) !== FALSE) {
        while (($dataRow = fgetcsv($handle)) !== FALSE) {
            $rows[] = $dataRow;
        }
        fclose($handle);
    }
}

// Prüfen, ob exakt derselbe Eintrag bereits existiert
$exists = false;
foreach ($rows as $row) {
    if (trim($row[0]) === trim($markerId) &&
        trim($row[1]) === trim($designation) &&
        trim($row[2]) === trim($link)) {
        $exists = true;
        break;
    }
}

// Falls nicht vorhanden, neuen Eintrag hinzufügen
if (!$exists) {
    $rows[] = [$markerId, $designation, $link];
}

// CSV neu schreiben
if (($handle = fopen($csvFile, "w")) !== FALSE) {
    foreach ($rows as $row) {
        if (fputcsv($handle, $row) === false) {
            echo json_encode(['success' => false, 'error' => 'Fehler beim Schreiben der CSV']);
            fclose($handle);
            exit;
        }
    }
    fclose($handle);
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'CSV-Datei konnte nicht geöffnet werden']);
}
?>
