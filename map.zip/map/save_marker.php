<?php
// save_marker.php

$file = 'markers.csv';
$headers = ['id', 'left', 'top', 'src', 'type', 'page'];

// Eingehende Daten (JSON) lesen
$data = json_decode(file_get_contents('php://input'), true);
if (!$data || !isset($data['id'])) {
    echo json_encode(['success' => false, 'error' => 'Ung�ltige Daten.']);
    exit;
}

// Bestehende Marker aus der CSV lesen (falls vorhanden)
$markers = [];
if (file_exists($file)) {
    if (($handle = fopen($file, 'r')) !== false) {
        $csvHeaders = fgetcsv($handle);
        while (($row = fgetcsv($handle)) !== false) {
            $markers[] = array_combine($csvHeaders, $row);
        }
        fclose($handle);
    }
}

// Pr�fen, ob ein Marker mit derselben ID existiert � aktualisieren oder hinzuf�gen
$found = false;
foreach ($markers as &$marker) {
    if ($marker['id'] === $data['id']) {
        $marker = $data;
        $found = true;
        break;
    }
}
unset($marker);
if (!$found) {
    $markers[] = $data;
}

// CSV neu schreiben
if (($handle = fopen($file, 'w')) !== false) {
    fputcsv($handle, $headers);
    foreach ($markers as $marker) {
        fputcsv($handle, [$marker['id'], $marker['left'], $marker['top'], $marker['src'], $marker['type'], $marker['page']]);
    }
    fclose($handle);
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Konnte markers.csv nicht �ffnen.']);
}
?>
