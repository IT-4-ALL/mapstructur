<?php
// upload.php

$uploadDir = 'uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if (isset($_FILES['bgImage'])) {
    $file = $_FILES['bgImage'];
    $filename = basename($file['name']);
    $targetFile = $uploadDir . time() . '_' . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        // Aktuellen Seitennamen aus POST-Daten holen (Standard: "default")
        $page = isset($_POST['page']) ? trim($_POST['page']) : "default";
        $configFile = 'config.json';
        $config = array();
        if (file_exists($configFile)) {
            $json = file_get_contents($configFile);
            $config = json_decode($json, true);
            if (!is_array($config)) {
                $config = array();
            }
        }
        // Hintergrundpfad f�r die aktuelle Seite speichern
        $config[$page] = $targetFile;
        file_put_contents($configFile, json_encode($config));
        echo json_encode(['success' => true, 'path' => $targetFile]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Fehler beim Upload.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Keine Datei ausgew�hlt.']);
}
?>
