<?php
// load_markers.php

$file = 'markers.csv';
$markers = [];
if (file_exists($file)) {
    if (($handle = fopen($file, 'r')) !== false) {
        $headers = fgetcsv($handle);
        while (($row = fgetcsv($handle)) !== false) {
            $markers[] = array_combine($headers, $row);
        }
        fclose($handle);
    }
}
echo json_encode($markers);
?>
