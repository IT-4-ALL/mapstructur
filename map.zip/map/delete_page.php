<?php
// delete_page.php

$file = 'pages.json';
if (file_exists($file)) {
    $json = file_get_contents($file);
    $pages = json_decode($json, true);
    if (!$pages) {
        $pages = ["default"];
    }
} else {
    $pages = ["default"];
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data || !isset($data['page'])) {
    echo json_encode(["success" => false, "error" => "Keine g�ltigen Daten empfangen."]);
    exit;
}

$pageToDelete = trim($data['page']);
if ($pageToDelete === "default") {
    echo json_encode(["success" => false, "error" => "Die Standardseite 'default' kann nicht gel�scht werden."]);
    exit;
}

// Entferne die Seite
$pages = array_filter($pages, function($page) use ($pageToDelete) {
    return $page !== $pageToDelete;
});

if (file_put_contents($file, json_encode(array_values($pages)))) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => "Konnte die Datei nicht speichern."]);
}
?>
